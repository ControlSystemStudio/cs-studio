package org.csstudio.opibuilder.widgetexample;

import org.csstudio.data.values.IValue;
import org.csstudio.data.values.ValueUtil;
import org.csstudio.opibuilder.editparts.AbstractPVWidgetEditPart;
import org.csstudio.opibuilder.model.AbstractPVWidgetModel;
import org.csstudio.opibuilder.properties.IWidgetPropertyChangeHandler;
import org.eclipse.draw2d.IFigure;

public class SimpleBarGraphEditpart extends AbstractPVWidgetEditPart {

	/**
	 * Create and initialize figure.
	 */
	@Override
	protected IFigure doCreateFigure() {
		SimpleBarGraphFigure figure = new SimpleBarGraphFigure();
		figure.setMin(getWidgetModel().getMin());
		figure.setMax(getWidgetModel().getMax());
		return figure;
	}
	
	/**Get the widget model.
	 * It is recommended that all widget controller should override this method.
	 *@return the widget model.
	 */
	@Override
	public SimpleBarGraphModel getWidgetModel() {
		return (SimpleBarGraphModel) super.getWidgetModel();
	}

	@Override
	protected void registerPropertyChangeHandlers() {
		// The handler when PV value changed.
		IWidgetPropertyChangeHandler valueHandler = new IWidgetPropertyChangeHandler() {
			public boolean handleChange(final Object oldValue,
					final Object newValue,
					final IFigure figure) {
				if(newValue == null)
					return false;
				 ((SimpleBarGraphFigure) figure).setValue(ValueUtil.getDouble((IValue)newValue));
				return false;
			}
		};
		setPropertyChangeHandler(AbstractPVWidgetModel.PROP_PVVALUE, valueHandler);
		
		//The handler when max property value changed.
		IWidgetPropertyChangeHandler maxHandler = new IWidgetPropertyChangeHandler() {
			
			public boolean handleChange(Object oldValue, Object newValue, IFigure figure) {
				((SimpleBarGraphFigure) figure).setMax((Double)newValue);
				return false;
			}
		};
		setPropertyChangeHandler(SimpleBarGraphModel.PROP_MAX, maxHandler);
		
		//The handler when min property value changed.
		IWidgetPropertyChangeHandler minHandler = new IWidgetPropertyChangeHandler() {
			
			public boolean handleChange(Object oldValue, Object newValue, IFigure figure) {
				((SimpleBarGraphFigure) figure).setMin((Double)newValue);
				return false;
			}
		};
		setPropertyChangeHandler(SimpleBarGraphModel.PROP_MIN, minHandler);
		
	}
	
	@Override
	public Object getValue() {
		return ((SimpleBarGraphFigure)getFigure()).getValue();
	}

	@Override
	public void setValue(Object value) {
		if(value instanceof Double)
			((SimpleBarGraphFigure)getFigure()).setValue((Double)value);
	}
}
