package org.csstudio.opibuilder.widgetexample;

import org.csstudio.opibuilder.actions.AbstractWidgetTargetAction;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;

public class WidgetContextMenuExample extends AbstractWidgetTargetAction{

	public void run(IAction action) {
		MessageDialog.openInformation(null, getSelectedWidget().getWidgetModel().getName(),
				"This dialog is opened from the Context menu of SimpleBar Graph.");
		
	}	
	
	/**
	 * @return the selected widget. In runmode, it is the editpart of the 
	 * widget on which the context menu was activated.
	 */
	protected final SimpleBarGraphEditpart getSelectedWidget() {
		return (SimpleBarGraphEditpart)getSelection().getFirstElement();
	}
}
