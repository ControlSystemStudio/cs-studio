gawk -f create_php.awk < index.html > index.php
