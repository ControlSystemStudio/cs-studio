/*
 * ============================================================================
 * GNU Lesser General Public License
 * ============================================================================
 *
 * Copyright (C) 2006-2009 Serotonin Software Technologies Inc. http://serotoninsoftware.com
 * @author Matthew Lohbihler
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 */
package com.serotonin.bacnet4j.apdu;

import com.serotonin.bacnet4j.exception.BACnetException;
import com.serotonin.bacnet4j.service.unconfirmed.UnconfirmedRequestService;
import com.serotonin.util.queue.ByteQueue;

public class UnconfirmedRequest extends APDU {
    public static final byte TYPE_ID = 1;

    /**
     * This parameter shall contain the parameters of the specific service that is being requested, encoded according 
     * to the rules of 20.2. These parameters are defined in the individual service descriptions in this standard and 
     * are represented in Clause 21 in accordance with the rules of ASN.1.
     */
    private final UnconfirmedRequestService service;
    
    public UnconfirmedRequest(UnconfirmedRequestService service) {
        this.service = service;
    }
    
    @Override
    public byte getPduType() {
        return TYPE_ID;
    }
    
    public UnconfirmedRequestService getService() {
        return service;
    }

    @Override
    public void write(ByteQueue queue) {
        queue.push(getShiftedTypeId(TYPE_ID));
        queue.push(service.getChoiceId());
        service.write(queue);
    }
    
    public UnconfirmedRequest(ByteQueue queue) throws BACnetException {
        queue.pop();
        byte choiceId = queue.pop();
        service = UnconfirmedRequestService.createUnconfirmedRequestService(choiceId, queue);
    }

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((service == null) ? 0 : service.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final UnconfirmedRequest other = (UnconfirmedRequest) obj;
        if (service == null) {
            if (other.service != null)
                return false;
        }
        else if (!service.equals(other.service))
            return false;
        return true;
    }

    @Override
    public boolean expectsReply() {
        return false;
    }
}
