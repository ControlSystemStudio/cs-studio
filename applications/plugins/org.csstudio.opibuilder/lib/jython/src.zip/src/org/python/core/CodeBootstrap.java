package org.python.core;

public interface CodeBootstrap {
    
    PyCode loadCode(CodeLoader loader);

}
