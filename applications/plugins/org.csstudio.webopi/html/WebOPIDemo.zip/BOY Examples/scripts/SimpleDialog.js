importPackage(Packages.org.eclipse.jface.dialogs);

MessageDialog.openInformation(
			null, "Dialog from JavaScript", "This is a dialog opened from JavaScript");

