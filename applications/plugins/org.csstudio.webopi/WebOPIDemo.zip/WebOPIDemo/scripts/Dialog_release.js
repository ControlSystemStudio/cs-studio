importPackage(Packages.org.eclipse.jface.dialogs);

MessageDialog.openInformation(
			null, "Dialog from JavaScript", "Button Released.");

