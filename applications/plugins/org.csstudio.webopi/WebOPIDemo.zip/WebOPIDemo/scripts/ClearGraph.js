display.getWidget("Graph2").clearGraph();

