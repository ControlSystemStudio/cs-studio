importPackage(Packages.org.csstudio.opibuilder.scriptUtil);
importPackage(Packages.org.eclipse.ui)

var helpFile=widget.getPropertyValue("name");

ScriptUtil.openWebPage("http://cs-studio.hg.sourceforge.net/hgweb/cs-studio/cs-studio-3.0/raw-file/f7f01ac1d1b4/applications/plugins/org.csstudio.opibuilder/html/" + helpFile);

