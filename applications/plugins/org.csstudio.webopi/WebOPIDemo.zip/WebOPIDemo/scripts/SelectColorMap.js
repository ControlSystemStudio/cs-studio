importPackage(Packages.org.csstudio.opibuilder.scriptUtil);

var value = PVUtil.getString(pvArray[0]);
	
//set colormap of IntensityGraph	
widgetController.setColorMap(value);
	

