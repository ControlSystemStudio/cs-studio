Example for Water Tank Heater as used in some EPICS
Database introductions.

Requires an EPICS base installation with a 'softIoc'
command to execute the EPICS database files like this:

  softIoc -m user=test -s -d tank.db -d control.db