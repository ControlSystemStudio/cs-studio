/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 2002-2004 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: QueueWorker.java,v 1.1 2004/11/26 01:50:35 tanderson Exp $
 */
package org.exolab.jms.common.threads;

import java.util.LinkedList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * This class creates an internal thread, adds it to the idleThread queue
 * and starts it running. The thread will then block on an internal queue
 * waitUntilWork for a runnable object to be passed to it. Once invoked
 * the thread will then call the objects run method.
 *
 * @version     $Revision: 1.1 $ $Date: 2004/11/26 01:50:35 $
 * @author      <a href="mailto:tma@netspace.net.au">Tim Anderson</a>
 * @see         ThreadPool
 */
class QueueWorker {

    /**
     * The owning thread pool
     */
    private ThreadPool _pool;

    /**
     * The queue of pending work
     */
    private LinkedList _queue = new LinkedList();

    /**
     * The worker thread
     */
    private Thread _worker;

    /**
     * A flag used to notify the thread to stop
     */
    private volatile boolean _stop = false;

    /**
     * The logger
     */
    private static final Log _log = LogFactory.getLog(QueueWorker.class);


    /**
     * The constructor creates the worker thread and runs it.
     * The new thread is given a unique id and added to the idle work queue.
     * The thread will then sleep until it is allocated work.
     *
     * @param pool the owning thread pool
     * @param group the thread group to add the worker thread to
     * @param name the name of the thread. This must be unique.
     */
    public QueueWorker(ThreadPool pool, ThreadGroup group, String name) {
        _pool = pool;

        Runnable worker = new Runnable() {
            public void run() {
                try {
                    runWork();
                } catch (Exception exception) {
                    _log.error("Thread " + _worker.getName()
                               + ": terminating on exception", exception);
                }
            }
        };

        // Create the new internal thread and start it all off.
        _worker = new Thread(group, worker, name);
        _worker.setDaemon(true);
        _worker.start();
    }

    /**
     * Queues a {@link Runnable} object to be executed.
     *
     * @param target the object to execute
     * @param listener the listener to notify when execution completes
     * (may be null)
     */
    public void add(Runnable target, CompletionListener listener) {
        synchronized (_queue) {
            _queue.add(new Executor(target, listener));
            _queue.notify();
        }
    }

    /**
     * Request the worker thread to stop
     */
    public void stop() {
        _stop = true;
        _worker.interrupt();
    }

    /**
     * Determines if the worker is alive
     *
     * @return <code>true</code> if the worker is alive
     */
    public boolean isAlive() {
        return _worker.isAlive();
    }

    /**
     * Executes queued {@link Runnable} instances, until {@link #stop} is
     * invoked.
     */
    private void runWork() {
        while (!_stop) {
            Runnable target = null;
            synchronized (_queue) {
                if (_queue.isEmpty()) {
                    try {
                        _queue.wait();
                    } catch (InterruptedException ignore) {
                    }
                } else {
                    target = (Executor) _queue.removeFirst();
                }
            }

            if (!_stop && target != null) {
                try {
                    _pool.execute(target);
                } catch (InterruptedException ignore) {
                }
            }
        }
    }

    /**
     * Executes a {@link Runnable}
     */
    private static class Executor implements Runnable {

        /**
         * The target to execute
         */
        private Runnable _target;

        /**
         * The listener to notify on completion. May be <code>null</code>
         */
        private CompletionListener _listener;

        /**
         * Construct a new <code>Executor</code>
         *
         * @param target the target to run
         * @param listener the listener to notify on completion.
         * May be <code>null</code>
         */
        public Executor(Runnable target, CompletionListener listener) {
            _target = target;
            _listener = listener;
        }

        /**
         * Run the target
         */
        public void run() {
            try {
                _target.run();
            } catch (Throwable exception) {
                _log.error("Thread " + Thread.currentThread().getName()
                           + " - uncaught exception fell through from run",
                           exception);
            } finally {
                if (_listener != null) {
                    _listener.completed(_target);
                }
            }
        }
    }

}
