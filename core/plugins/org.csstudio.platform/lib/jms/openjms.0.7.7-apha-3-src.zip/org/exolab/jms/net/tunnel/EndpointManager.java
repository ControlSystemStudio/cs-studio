/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 2004 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: EndpointManager.java,v 1.1 2004/11/26 01:51:17 tanderson Exp $
 */

package org.exolab.jms.net.tunnel;

import java.io.IOException;
import java.net.Socket;
import java.rmi.server.ObjID;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


/**
 * Manages connections for {@link TunnelServlet}
 *
 * @author <a href="mailto:tma@netspace.net.au">Tim Anderson</a>
 * @version $Revision: 1.1 $ $Date: 2004/11/26 01:51:17 $
 */
class EndpointManager {

    /**
     * A map of <code>EndpointInfo</code>, keyed on identifier
     */
    private Map _endpoints = Collections.synchronizedMap(new HashMap());

    /**
     * Create a new endpoint
     *
     * @param host the host to connect to
     * @param port the port to connect to
     * @return the identifier of the new endpoint
     * @throws IOException for any I/O error
     */
    public String open(String host, int port) throws IOException {
        Socket socket = new Socket(host, port);
        String id = new ObjID().toString();
        EndpointInfo result = new EndpointInfo(id, socket);
        _endpoints.put(id, result);
        return id;
    }

    /**
     * Returns a {@link EndpointInfo} given its identifier
     *
     * @param id the endpoint identifier
     * @return the connection corresponding to <code>id</code> or
     *         <code>null</code> if none exists
     */
    public EndpointInfo getEndpointInfo(String id) {
        return (EndpointInfo) _endpoints.get(id);
    }

    /**
     * Returns an endpoint given its identifier
     *
     * @param id the endpoint identifier
     * @return the endpoint corresponding to <code>id</code> or
     *         <code>null</code>
     */
    public Socket getEndpoint(String id) {
        Socket endpoint = null;
        EndpointInfo info = getEndpointInfo(id);
        if (info != null) {
            endpoint = info.getEndpoint();
        }
        return endpoint;
    }

    /**
     * Close a connection given its identifier
     *
     * @param id the connection identifier
     * @throws IOException for any I/O error
     */
    public void close(String id) throws IOException {
        Socket endpoint = getEndpoint(id);
        if (endpoint != null) {
            try {
                endpoint.close();
            } finally {
                _endpoints.remove(id);
            }
        }
    }

}
