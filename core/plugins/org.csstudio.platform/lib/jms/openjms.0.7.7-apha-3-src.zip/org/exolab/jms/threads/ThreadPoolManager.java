/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 2000-2005 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: ThreadPoolManager.java,v 1.3 2005/12/20 21:43:41 tanderson Exp $
 */
package org.exolab.jms.threads;

import java.util.HashMap;

import org.exolab.jms.common.threads.ThreadPool;
import org.exolab.jms.service.Service;


/**
 * The thread pool manager manages all the required {@link ThreadPool} objects.
 * The clients can obtain a ThreadPool from the {@link ThreadPoolManager} with a
 * given number of Threads.
 * <p/>
 * The manager keeps a list of all The ThreadPools it has dished out with a
 * unique client provided name. Client can then re-request the already created
 * ThreadPool or share common ThreadPools if required.
 * <p/>
 * The ThreadPool manager will attempt to shutdown all ThreadPools and stop all
 * Threads when it receives a stop request.
 * <p/>
 * If a client attempts to create a ThreadPool with a name that already exists a
 * ThreadPoolExistsException will be raised and the creation will fail.
 *
 * @author <a href="mailto:mourikis@intalio.com">Jim Mourikis</a>
 * @version $Revision: 1.3 $ $Date: 2005/12/20 21:43:41 $
 */
public class ThreadPoolManager extends Service {

    /**
     * The set of named threadpools.
     */
    private final HashMap _pools = new HashMap();

    /**
     * The constructor initialises the parent, and creates an empty container to
     * hold the thread pools, as they are requested.
     * <p/>
     * <P> Entry into this constructor is only through the intialise method
     * below. Note only one instance of this mgr is created.
     */
    public ThreadPoolManager() {
        super("ThreadPoolManager");
    }

    /**
     * A client has requested a new thread pool creation with the given name. if
     * the named Pool has not already been created, then create it add it to the
     * list, and return it to the client.
     *
     * @param name The unique name given to this ThreadPool
     * @param size The maximum nuber of Threads this pool contains.
     * @throws ThreadPoolExistsException if the pool with the given name already
     *                                   exists.
     */
    public ThreadPool createThreadPool(String name, int size)
            throws ThreadPoolExistsException {
        synchronized (_pools) {
            if (_pools.containsKey(name)) {
                throw new ThreadPoolExistsException("ThreadPool with name " +
                                                    name + " exists");
            }
            ThreadPool pool = new ThreadPool(name, size, true);

            _pools.put(name, pool);
            return pool;
        }
    }

    /**
     * Get the ThreadPool with the given name. if the named pool does not exist
     * throw an exception.
     *
     * @param name The unique name of the requested ThreadPool
     * @throws UnknownThreadPoolException if the pool with the given name does
     *                                    not exist.
     */
    public ThreadPool getThreadPool(String name)
            throws UnknownThreadPoolException {
        ThreadPool pool = null;

        synchronized (_pools) {
            pool = (ThreadPool) _pools.get(name);
        }

        if (pool == null) {
            throw new UnknownThreadPoolException("ThreadPool with name " +
                                                 name + " does not exist");
        }

        return pool;
    }

    /**
     * Clean up all thread pools.
     */
    protected void doStop()  {
        synchronized (_pools) {
            Object[] ob = _pools.values().toArray();

            for (int i = 0, j = _pools.size(); i < j; i++) {
                ((ThreadPool) ob[i]).stopRequestAllWorkers();
            }
            _pools.clear();
        }
    }

}
