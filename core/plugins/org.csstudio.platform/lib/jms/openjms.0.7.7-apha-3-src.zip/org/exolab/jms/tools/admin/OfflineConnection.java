/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 2000,2003 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: OfflineConnection.java,v 1.2 2005/08/30 14:04:11 tanderson Exp $
 *
 * Date         Author  Changes
 * $Date	    jimm    Created
 */


package org.exolab.jms.tools.admin;

import java.awt.*;
import java.sql.Connection;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.swing.*;

import org.exolab.jms.authentication.User;
import org.exolab.jms.client.JmsDestination;
import org.exolab.jms.client.JmsQueue;
import org.exolab.jms.client.JmsTopic;
import org.exolab.jms.config.Configuration;
import org.exolab.jms.config.DatabaseConfiguration;
import org.exolab.jms.persistence.DatabaseService;
import org.exolab.jms.persistence.PersistenceException;


/**
 * Connect directly to the Persistent store to retrieve information and perfrom
 * updates.
 * <p/>
 * <P> Note: If the OpenJMSServer is active, this connection will fail, since it
 * requires and exclusive lock on the database to avoid database corruption.
 * Similarly, if this connection is active the OpenJMSServer cannot be started
 * for the same reasons.
 *
 * @author <a href="mailto:mourikis@exolab.org">Jim Mourikis</a>
 * @version $Revision: 1.2 $ $Date: 2005/08/30 14:04:11 $
 * @see		AbstractAdminConnection
 * @see		AdminMgr
 */
public class OfflineConnection extends AbstractAdminConnection {

    // The parent Gui
    private Component _parent;

    // The deafult JNDI context.
    private Context _context = null;

    /**
     * The database service.
     */
    private DatabaseService _database;

    /**
     * Connect to the RMIAdmin Server if in online mode, or open the database
     * and update the data directly in offline mode.
     *
     * @param parent The component parent.
     * @throws OfflineConnectionException When the database cannot be opened
     */
    public OfflineConnection(Component parent, Configuration config)
            throws OfflineConnectionException {
        try {
            if (_instance == null) {
                _parent = parent;
                _database = new DatabaseService(config);

                DatabaseConfiguration dbconfig =
                        config.getDatabaseConfiguration();

                // determine the database type and instantiate the appropriate
                // database adapter
                if (dbconfig.getRdbmsDatabaseConfiguration() != null) {
                    _database.getAdapter();
                    _instance = this;
                }
            } else {
                throw new OfflineConnectionException("Already connected");
            }
        } catch (Exception err) {
            throw new OfflineConnectionException
                    ("Database Error: " + err.getMessage());
        }
    }

    // implementation of AbstractAdminConnection.close
    public void close() {
        _database.getAdapter().close();
        _instance = null;
    }

    // implementation of AbstractAdminConnection.addDurableConsumer
    public boolean addDurableConsumer(String topic, String name) {
        boolean result = false;
        try {
            Connection connection = _database.getConnection();
            _database.getAdapter().addDurableConsumer(connection, topic,
                                                      name);
            _database.commit();
            result = true;
        } catch (PersistenceException exception) {
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }

        return result;
    }

    // implementation of AbstractAdminConnection.removeDurableConsumer
    public boolean removeDurableConsumer(String name) {
        boolean result = false;

        try {
            Connection connection = _database.getConnection();

            _database.getAdapter().removeDurableConsumer(connection, name);
            _database.commit();
            result = true;
        } catch (PersistenceException exception) {
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }
        return result;
    }

    // implementation of AbstractAdminConnection.unregisterConsumer
    public boolean unregisterConsumer(String name) {
        return false;
    }

    // implementation of AbstractAdminConnection.isConnected
    public boolean isConnected(String name) {
        return false;
    }

    // implementation of AbstractAdminConnection.getAllDestinations
    public Enumeration getAllDestinations() {
        Enumeration result = null;
        try {
            Connection connection = _database.getConnection();

            result = _database.getAdapter().getAllDestinations(connection);
            _database.commit();
        } catch (PersistenceException exception) {
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }

        return result;
    }

    // implementation of AbstractAdminConnection.addDestination
    public boolean addDestination(String destination, boolean isQueue) {
        boolean success = false;

        try {
            Connection connection = _database.getConnection();

            _database.getAdapter().addDestination(connection,
                                                  destination, isQueue);
            if (_context == null) {
                // connect to the JNDI server and get a reference to
                // root context
                Hashtable props = new Hashtable();
                props.put(Context.INITIAL_CONTEXT_FACTORY,
                          "org.exolab.jms.jndi.intravm.IntravmJndiServer");
                _context = new InitialContext(props);
            }

            Object ob = (isQueue ? (Object) (new JmsQueue(destination)) :
                    (Object) (new JmsTopic(destination)));

            if (ob instanceof JmsQueue) {
                ((JmsDestination) ob).setPersistent(true);
            }

            _context.rebind(destination, ob);
            _database.commit();
            success = true;
        } catch (PersistenceException exception) {
            System.err.println("Failed to add destination " + destination +
                               " b/c " + exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        } catch (javax.naming.NamingException err) {
            System.err.println("Failed to add " + destination +
                               " in JNDI context");
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }

        return success;
    }

    // implementation of AbstractAdminConnection.getDurableConsumerMessageCount
    public int getDurableConsumerMessageCount(String topic, String name) {
        int count = -1;


        try {
            Connection connection = _database.getConnection();

            count = _database.getAdapter().getDurableConsumerMessageCount(
                    connection, topic, name);
            _database.commit();
        } catch (PersistenceException exception) {
            System.err.println("Failed to get message count for " + topic +
                               " b/c " + exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }
        return count;
    }

    // implementation of AbstractAdminConnection.getQueueMessageCount
    public int getQueueMessageCount(String queue) {
        int count = -1;


        try {
            Connection connection = _database.getConnection();

            count = _database.getAdapter().getQueueMessageCount(connection,
                                                                queue);
            _database.commit();
        } catch (PersistenceException exception) {
            System.err.println("Failed to get message count for " + queue +
                               " b/c " + exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }

        return count;
    }

    // implementation of AbstractAdminConnection.durableConsumerExists
    public boolean durableConsumerExists(String name) {
        boolean result = false;


        try {
            Connection connection = _database.getConnection();

            result = _database.getAdapter().durableConsumerExists(connection,
                                                                  name);
            _database.commit();
        } catch (PersistenceException exception) {
            System.err.println("Failed on consumer exists for " + name +
                               " b/c " + exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }

        return result;
    }

    // implementation of AbstractAdminConnection.getDurableConsumers
    public Enumeration getDurableConsumers(String topic) {
        Enumeration result = null;


        try {
            Connection connection = _database.getConnection();

            result = _database.getAdapter().getDurableConsumers(connection,
                                                                topic);
            _database.commit();
        } catch (PersistenceException exception) {
            System.err.println("Failed on getDurableConsumers for " + topic +
                               " b/c " + exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }
        return result;
    }

    // implementation of AbstractAdminConnection.removeDestination
    public boolean removeDestination(String destination) {
        boolean result = false;


        try {
            Connection connection = _database.getConnection();

            _database.getAdapter().removeDestination(connection,
                                                     destination);
            if (_context == null) {
                // connect to the JNDI server and get a reference to
                // root context
                Hashtable props = new Hashtable();
                props.put(Context.INITIAL_CONTEXT_FACTORY,
                          "org.exolab.jms.jndi.intravm.IntravmJndiServer");
                _context = new InitialContext(props);
            }
            _context.unbind(destination);
            _database.commit();
            result = true;
        } catch (PersistenceException exception) {
            System.err.println("Failed on getDurableConsumers for " +
                               destination + " b/c " + exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        } catch (javax.naming.NamingException err) {
            System.err.println("Failed to removeDestination " + destination +
                               " b/c" + err.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }

        return result;
    }

    // implementation of AbstractAdminConnection.purgeMessages
    public int purgeMessages() {
        return _database.getAdapter().purgeMessages();
    }

    // implementation of AbstractAdminConnection.stopServer
    public void stopServer() {
        JOptionPane.showMessageDialog
                (_parent, "Not available in offline mode",
                 "Shutdown Error", JOptionPane.ERROR_MESSAGE);
    }

    // implementation of AbstractAdminConnection.addUser
    public boolean addUser(String username, String password) {

        boolean success = false;

        try {
            Connection connection = _database.getConnection();

            _database.getAdapter().addUser(connection,
                                           new User(username, password));
            _database.commit();
            success = true;
        } catch (PersistenceException exception) {
            System.err.println("Failed to add user " + username +
                               exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }
        return success;
    }

    // implementation of AbstractAdminConnection.changePassord
    public boolean changePassword(String username, String password) {

        boolean success = false;

        try {
            Connection connection = _database.getConnection();

            _database.getAdapter().updateUser(connection,
                                              new User(username, password));
            _database.commit();
            success = true;
        } catch (PersistenceException exception) {
            System.err.println("Failed to add user " + username +
                               exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }
        return success;
    }

    // implementation of AbstractAdminConnection.removeUser
    public boolean removeUser(String username) {
        boolean result = false;


        try {
            Connection connection = _database.getConnection();

            _database.getAdapter().removeUser(connection,
                                              new User(username, null));
            _database.commit();
            result = true;
        } catch (PersistenceException exception) {
            System.err.println("Failed on remove user for " +
                               username + exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }

        return result;
    }

    // implementation of AbstractAdminConnection.getAllUsers
    public Enumeration getAllUsers() {
        Enumeration result = null;


        try {
            Connection connection = _database.getConnection();

            result = _database.getAdapter().getAllUsers(connection);
            _database.commit();
        } catch (PersistenceException exception) {
            System.err.println("Failed on getAllUsers "
                               + exception.toString());
            try {
                _database.rollback();
            } catch (Exception nested) {
                // ignore
            }
        }

        return result;
    }
} //-- OfflineConnection
