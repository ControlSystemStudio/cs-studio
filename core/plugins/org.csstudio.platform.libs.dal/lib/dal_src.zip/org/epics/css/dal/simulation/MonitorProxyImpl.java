/*
 * Copyright (c) 2006 Stiftung Deutsches Elektronen-Synchroton,
 * Member of the Helmholtz Association, (DESY), HAMBURG, GERMANY.
 *
 * THIS SOFTWARE IS PROVIDED UNDER THIS LICENSE ON AN "../AS IS" BASIS.
 * WITHOUT WARRANTY OF ANY KIND, EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR PARTICULAR PURPOSE AND
 * NON-INFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
 * FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 * THE USE OR OTHER DEALINGS IN THE SOFTWARE. SHOULD THE SOFTWARE PROVE DEFECTIVE
 * IN ANY RESPECT, THE USER ASSUMES THE COST OF ANY NECESSARY SERVICING, REPAIR OR
 * CORRECTION. THIS DISCLAIMER OF WARRANTY CONSTITUTES AN ESSENTIAL PART OF THIS LICENSE.
 * NO USE OF ANY SOFTWARE IS AUTHORIZED HEREUNDER EXCEPT UNDER THIS DISCLAIMER.
 * DESY HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS,
 * OR MODIFICATIONS.
 * THE FULL LICENSE SPECIFYING FOR THE SOFTWARE THE REDISTRIBUTION, MODIFICATION,
 * USAGE AND OTHER RIGHTS AND OBLIGATIONS IS INCLUDED WITH THE DISTRIBUTION OF THIS
 * PROJECT IN THE FILE LICENSE.HTML. IF THE LICENSE IS NOT INCLUDED YOU MAY FIND A COPY
 * AT HTTP://WWW.DESY.DE/LEGAL/LICENSE.HTM
 */

/**
 *
 */
package org.epics.css.dal.simulation;

import org.epics.css.dal.DataExchangeException;
import org.epics.css.dal.RemoteException;
import org.epics.css.dal.Request;
import org.epics.css.dal.ResponseListener;
import org.epics.css.dal.impl.RequestImpl;
import org.epics.css.dal.impl.ResponseImpl;
import org.epics.css.dal.proxy.MonitorProxy;

import java.util.TimerTask;


/**
 * Simulation implementation of MonitorProxy.
 *
 * @author Igor Kriznar (igor.kriznarATcosylab.com)
 */
public class MonitorProxyImpl extends RequestImpl implements MonitorProxy,
	Runnable
{
	protected PropertyProxyImpl<?> proxy;
	protected long timerTrigger = 1000;
	protected boolean heartbeat = true;
	protected TimerTask task;
	protected boolean destroyed = false;

	/**
	 * Creates new instance.
	 *
	 * @param proxy parent proxy object
	 * @param l listener for notifications
	 */
	public MonitorProxyImpl(PropertyProxyImpl proxy, ResponseListener l)
	{
		super(proxy, l);
		this.proxy = proxy;
		resetTimer();
	}

	public void reInitialize(PropertyProxyImpl proxy) throws RemoteException
	{
		this.source = proxy;
		this.proxy = proxy;
	}

	/* (non-Javadoc)
	 * @see org.epics.css.dal.proxy.MonitorProxy#getRequest()
	 */
	public Request getRequest()
	{
		return this;
	}

	/* (non-Javadoc)
	 * @see org.epics.css.dal.SimpleMonitor#getTimerTrigger()
	 */
	public long getTimerTrigger() throws DataExchangeException
	{
		return timerTrigger;
	}

	/* (non-Javadoc)
	 * @see org.epics.css.dal.SimpleMonitor#setTimerTrigger(long)
	 */
	public void setTimerTrigger(long trigger)
		throws DataExchangeException, UnsupportedOperationException
	{
		timerTrigger = trigger;
		resetTimer();
	}

	/* (non-Javadoc)
	 * @see org.epics.css.dal.SimpleMonitor#setHeartbeat(boolean)
	 */
	public void setHeartbeat(boolean heartbeat)
		throws DataExchangeException, UnsupportedOperationException
	{
		this.heartbeat = heartbeat;
		resetTimer();
	}

	/* (non-Javadoc)
	 * @see org.epics.css.dal.SimpleMonitor#isHeartbeat()
	 */
	public boolean isHeartbeat()
	{
		return heartbeat;
	}

	/* (non-Javadoc)
	 * @see org.epics.css.dal.SimpleMonitor#getDefaultTimerTrigger()
	 */
	public long getDefaultTimerTrigger() throws DataExchangeException
	{
		return 1000;
	}

	/* (non-Javadoc)
	 * @see org.epics.css.dal.SimpleMonitor#isDefault()
	 */
	public boolean isDefault()
	{
		return true;
	}

	private void fireValueEvent()
	{
		try {
			ResponseImpl r = new ResponseImpl(proxy, this,
				    proxy.getValueSync(), "value", true, null,
				    proxy.getCondition(), null, false);
			addResponse(r);
		} catch (DataExchangeException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Fires value change event if monitor is not in heartbeat mode.
	 */
	public void fireValueChange()
	{
		if (!heartbeat) {
			fireValueEvent();
		}
	}

	/**
	 * Run method executed at schedulet time intervals.
	 */
	public void run()
	{
		fireValueEvent();
	}

	private synchronized void resetTimer()
	{
		if (task != null) {
			task.cancel();
		}

		if (heartbeat) {
			task = SimulatorPlug.getInstance().schedule(this, timerTrigger);
		}
	}

	/* (non-Javadoc)
	 * @see org.epics.css.dal.SimpleMonitor#destroy()
	 */
	public void destroy()
	{
		if (task != null) {
			task.cancel();
		}

		destroyed = true;
	}

	/* (non-Javadoc)
	 * @see org.epics.css.dal.SimpleMonitor#isDestroyed()
	 */
	public boolean isDestroyed()
	{
		return destroyed;
	}

	public void refresh()
	{
		// Override in order to clean up cached values.
	}
}

/* __oOo__ */
