package com.publicobject.amazonbrowser;

import ca.odell.glazedlists.gui.TreeFormat;

public class ItemTreeFormat implements TreeFormat {

    public Object getParent(Object e) {
        return null;
    }
}